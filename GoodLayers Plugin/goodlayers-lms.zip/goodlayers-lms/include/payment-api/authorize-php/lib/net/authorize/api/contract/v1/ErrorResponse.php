<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing ErrorResponse
 */
class ErrorResponse extends ANetApiResponseType
{


}

