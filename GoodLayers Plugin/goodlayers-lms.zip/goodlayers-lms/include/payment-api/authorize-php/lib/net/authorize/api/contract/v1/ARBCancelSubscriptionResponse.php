<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing ARBCancelSubscriptionResponse
 */
class ARBCancelSubscriptionResponse extends ANetApiResponseType
{


}

